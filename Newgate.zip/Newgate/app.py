from flask import Flask, request, jsonify, render_template
import numpy as np
from tensorflow.keras.models import load_model

app = Flask(__name__)
model = load_model('seismic_model.h5')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)
    recent_data = np.array(data['recent_data'])
    seq_length = recent_data.shape[0]

    # Reshape pour LSTM
    recent_data = recent_data.reshape((1, seq_length, recent_data.shape[1]))
    
    # Prédiction
    future_pred = model.predict(recent_data)
    return jsonify({'prediction': future_pred.tolist()})

if __name__ == '__main__':
    app.run(debug=True)
