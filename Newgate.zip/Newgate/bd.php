<?php
// Permettre les requêtes depuis n'importe quel domaine
header("Access-Control-Allow-Origin: *");

// Connexion à la base de données avec PDO
$servername = "localhost";
$username = "root"; // Nom d'utilisateur MySQL
$password = ""; // Mot de passe MySQL (dans ce cas, il est vide)
$dbname = "newgate"; // Nom de la base de données

try {
    // Connexion à la base de données
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Paramétrer le mode d'erreur PDO à exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Récupérer l'année et l'échelle de magnitude à partir de la requête
    $year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
    $magnitudeRange = isset($_GET['magnitude']) ? $_GET['magnitude'] : '0-10'; // Par défaut, tous les séismes sont inclus

    // Extraire les bornes de l'échelle de magnitude
    list($minMagnitude, $maxMagnitude) = explode('-', $magnitudeRange);

    // Préparer et exécuter la requête SQL avec filtrage par année et magnitude
    $stmt = $conn->prepare("SELECT Place, Latitude, Longitude, Mag, Time FROM earthquake WHERE YEAR(Time) = :year AND Mag >= :minMagnitude AND Mag < :maxMagnitude");
    $stmt->bindParam(':year', $year, PDO::PARAM_INT);
    $stmt->bindParam(':minMagnitude', $minMagnitude, PDO::PARAM_INT);
    $stmt->bindParam(':maxMagnitude', $maxMagnitude, PDO::PARAM_INT);
    $stmt->execute();
    
    // Initialisation du tableau de données GeoJSON
    $geojson = array(
        'type' => 'FeatureCollection',
        'features' => array()
    );
    
    // Récupérer les résultats de la requête et stocker les données dans un tableau
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $feature = array(
            'type' => 'Feature',
            'geometry' => array(
                'type' => 'Point',
                'coordinates' => array(floatval($row['Longitude']), floatval($row['Latitude']))
            ),
            'properties' => array(
                'Place' => $row['Place'],
                'Mag' => $row['Mag'],
                'Time' => $row['Time']
            )
        );
        // Ajouter l'entité GeoJSON au tableau
        array_push($geojson['features'], $feature);
    }
    
    // Convertir le tableau GeoJSON en format JSON
    $geojson_string = json_encode($geojson);

    // Vérifier si l'encodage JSON a réussi
    if ($geojson_string === false) {
        throw new Exception('Erreur lors de l\'encodage JSON.');
    }

    // Retourner les données GeoJSON
    header('Content-Type: application/json');
    echo $geojson_string;

} catch(PDOException $e) {
    // Afficher l'erreur PDO
    echo "Erreur PDO : " . $e->getMessage();
} catch(Exception $e) {
    // Afficher l'erreur générique
    echo "Erreur : " . $e->getMessage();
}

// Fermer la connexion à la base de données
$conn = null;
?>
