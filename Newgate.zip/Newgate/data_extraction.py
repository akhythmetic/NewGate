import pandas as pd
from sqlalchemy import create_engine

def extract_data():
    # Connexion à la base de données
    engine = create_engine('mysql://username:password@host:port/database')

    # Extraction des données
    query = "SELECT Longitude, Latitude, Mag, Time FROM earthquakes"
    df = pd.read_sql(query, engine)

    # Conversion de la colonne Time en datetime
    df['Time'] = pd.to_datetime(df['Time'])

    # Extraction de l'année et du mois
    df['Year'] = df['Time'].dt.year
    df['Month'] = df['Time'].dt.month

    # Suppression de la colonne Time
    df = df.drop(columns=['Time'])

    return df

if __name__ == "__main__":
    df = extract_data()
    print(df.head())
