import numpy as np
from sklearn.preprocessing import MinMaxScaler

def preprocess_data(df):
    # Normalisation des données
    scaler = MinMaxScaler()
    df[['Longitude', 'Latitude', 'Mag']] = scaler.fit_transform(df[['Longitude', 'Latitude', 'Mag']])

    # Création des séquences pour LSTM
    def create_sequences(data, seq_length):
        xs, ys = [], []
        for i in range(len(data) - seq_length):
            x = data[i:i+seq_length]
            y = data[i+seq_length]
            xs.append(x)
            ys.append(y)
        return np.array(xs), np.array(ys)

    seq_length = 10  # Utiliser les 10 dernières observations pour prédire la prochaine
    features = df[['Longitude', 'Latitude', 'Year', 'Month', 'Mag']].values
    X, y = create_sequences(features, seq_length)

    # Division en ensembles d'entraînement et de test
    train_size = int(len(X) * 0.8)
    X_train, X_test = X[:train_size], X[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]

    # Reshape pour LSTM
    X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], X_train.shape[2]))
    X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], X_test.shape[2]))

    return X_train, X_test, y_train, y_test

if __name__ == "__main__":
    from data_extraction import extract_data
    df = extract_data()
    X_train, X_test, y_train, y_test = preprocess_data(df)
    print(X_train.shape, X_test.shape)
