<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planisphère - Newgate</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="newgate.css">
    <style>
        /* Couleurs de fond pour chaque section */
        .section1 {
            background-color: #960018;
            height: 300px; /* Hauteur de la section */
        }
        /* Style pour le texte dans la première section */
        .section1 .center-text {
            color: white;
            font-size: 24px; /* Taille de police plus grosse */
            text-align: center; /* Centrage horizontal */
            margin-bottom: 0; /* Supprimer la marge en bas */
        }
    </style>

    <!-- Inclure la bibliothèque Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="xxx" crossorigin=""/>

    <!-- Inclure le script Leaflet -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="xxx" crossorigin=""></script>
</head>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <a class="navbar-brand" href="#">
            <img src="images/logo.png" alt="Logo du site">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.html">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="planisphere.php">Planisphère</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Documentation
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="repertoire_des_seismes.html">Répertoire des séismes</a>
                        <a class="dropdown-item" href="formation_des_seismes.html">Formation des séismes</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="predictions.html">Prédictions</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0 search-button" type="submit">Search</button>
            </form>
        </div>
    </nav>

    <div class="section section1 d-flex justify-content-center align-items-center">
        <div>
            <p class="center-text">Planisphère contenant les séismes répertoriés depuis 1900</p>
        </div>
    </div>

    <!-- Conteneur pour la carte -->
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div id="map" style="height: 400px;"></div>
            </div>
        </div>
    </div>

    <!-- Menu déroulant pour sélectionner l'année -->
    <select id="yearSelect">
        <?php
        // Générer les options pour les années (depuis 1900 jusqu'à l'année actuelle)
        $currentYear = date('Y');
        for ($i = $currentYear; $i >= 1900; $i--) {
            echo "<option value='$i'>$i</option>";
        }
        ?>
    </select>

    <!-- Menu déroulant pour sélectionner l'échelle de magnitude -->
    <select id="magSelect">
        <option value="0-2">0-2</option>
        <option value="2-4">2-4</option>
        <option value="4-6">4-6</option>
        <option value="6-8">6-8</option>
        <option value="8-10">8-10</option>
    </select>

    <!-- Bouton pour charger les données -->
    <button id="loadDataBtn">Charger les données</button>

    <!-- Div pour afficher les données (à remplir dynamiquement) -->
    <div id="dataContainer"></div>

    <!-- Script JavaScript pour charger les données -->
    <script>
        // Initialiser la carte Leaflet
        var map = L.map('map').setView([0, 0], 2);

        // Ajouter une couche de tuiles OpenStreetMap à la carte
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Variable pour stocker la couche GeoJSON
        var geojsonLayer;

        // Charger les données GeoJSON depuis le fichier PHP
        function loadData() {
            var year = document.getElementById('yearSelect').value;
            var magnitudeRange = document.getElementById('magSelect').value;
            var url = 'http://localhost/Newgate/bd.php?year=' + year + '&magnitude=' + magnitudeRange;
            
            // Requête AJAX pour charger les données GeoJSON avec l'année et l'échelle de magnitude sélectionnées
            fetch(url)
            .then(response => response.json())
            .then(data => {
                console.log(data); // Afficher les données dans la console
                
                // Effacer les données précédentes de la carte
                if (geojsonLayer) {
                    geojsonLayer.removeFrom(map);
                }
                
                // Ajouter les données GeoJSON à la carte
                geojsonLayer = L.geoJSON(data, {
                    onEachFeature: function(feature, layer) {
                        // Créer le contenu HTML pour les détails de la localité
                        var content = '<h3>' + feature.properties.Place + '</h3>' +
                                      '<p>Latitude: ' + feature.geometry.coordinates[1] + '</p>' +
                                      '<p>Longitude: ' + feature.geometry.coordinates[0] + '</p>' +
                                      '<p>Magnitude: ' + feature.properties.Mag + '</p>' +
                                      '<p>Date: ' + feature.properties.Time + '</p>';
                        
                        // Ajouter un événement de clic pour afficher les détails lorsque vous cliquez sur la localité
                        layer.bindPopup(content);
                    }
                }).addTo(map);
            })
            .catch(error => console.error('Erreur lors du chargement des données :', error));
        }

        // Écouter l'événement de clic sur le bouton pour charger les données
        document.getElementById('loadDataBtn').addEventListener('click', loadData);
    </script>

     <!-- Bas de page -->
    <footer>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-left">
                    <img src="images/logo.png" alt="Logo du bas de page" style="max-width: 300px;">
                </div>
                <div class="col-md-6 text-center">
                    <a href="contacts.html" style="color: white; text-decoration: underline;">Contact des développeurs</a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
