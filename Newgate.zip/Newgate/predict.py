import numpy as np
from keras.models import load_model
from sklearn.metrics import mean_squared_error

def load_trained_model(model_path):
    return load_model(model_path)

def predict_future(model, recent_data, seq_length):
    recent_data = recent_data.reshape((1, seq_length, recent_data.shape[1]))
    future_pred = model.predict(recent_data)
    return future_pred

if __name__ == "__main__":
    from data_preprocessing import preprocess_data
    from data_extraction import extract_data
    
    df = extract_data()
    _, X_test, _, y_test = preprocess_data(df)
    
    model = load_trained_model('seismic_model.h5')
    
    # Prédictions sur les données de test
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    print(f'Erreur quadratique moyenne (MSE) : {mse}')
    
    # Prédiction future
    recent_data = df[['Longitude', 'Latitude', 'Year', 'Month', 'Mag']].values[-10:]  # Dernières 10 observations
    future_pred = predict_future(model, recent_data, 10)
    print(f'Prédiction future : {future_pred}')
