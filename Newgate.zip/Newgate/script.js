document.getElementById('prediction-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const recentData = document.getElementById('recent_data').value;

    fetch('/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ recent_data: JSON.parse(recentData) })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('prediction').textContent = JSON.stringify(data.prediction, null, 2);
    })
    .catch(error => console.error('Error:', error));
});
