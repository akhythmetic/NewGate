from keras.models import Sequential
from keras.layers import LSTM, Dense
from sklearn.metrics import mean_squared_error

def build_model(input_shape):
    model = Sequential()
    model.add(LSTM(50, return_sequences=True, input_shape=input_shape))
    model.add(LSTM(50))
    model.add(Dense(input_shape[1]))

    model.compile(optimizer='adam', loss='mse')
    return model

def train_model(X_train, y_train):
    model = build_model((X_train.shape[1], X_train.shape[2]))
    model.fit(X_train, y_train, epochs=20, batch_size=32, validation_split=0.2)
    return model

if __name__ == "__main__":
    from data_preprocessing import preprocess_data
    from data_extraction import extract_data

    df = extract_data()
    X_train, X_test, y_train, y_test = preprocess_data(df)
    model = train_model(X_train, y_train)
    
    # Évaluation du modèle
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    print(f'Erreur quadratique moyenne (MSE) : {mse}')
    
    # Sauvegarde du modèle
    model.save('seismic_model.h5')
